@extends('layouts.auth')

@section('content')
    <login/>
@endsection
