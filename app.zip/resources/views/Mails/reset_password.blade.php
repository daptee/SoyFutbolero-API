<div>
    Su nueva clave es {{ $password }}
</div>
